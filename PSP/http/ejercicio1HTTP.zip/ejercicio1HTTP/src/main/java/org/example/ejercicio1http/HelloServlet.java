package org.example.ejercicio1http;

import org.example.config.Constants;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.web.servlet.JakartaServletWebApplication;

import java.io.IOException;

@WebServlet("/login")
public class HelloServlet extends HttpServlet {

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String nombre = request.getParameter(Constants.PARAM_NOMBRE);

        var webExchange = JakartaServletWebApplication.buildApplication(getServletContext())
                .buildExchange(request, response);
        WebContext ctx = new WebContext(webExchange);
        ctx.setVariable(Constants.VAR_NOMBRE, nombre);

        response.setContentType(Constants.CONTENT_TYPE);
        ((TemplateEngine)getServletContext().getAttribute(Constants.TEMPLATE_ENGINE_ATTR))
                .process(Constants.TEMPLATE_JUEGO, ctx, response.getWriter());
    }



}