package org.example.config;

public class Constants {
    private Constants() {
        throw new UnsupportedOperationException("Esta es una clase de utilidad");
    }

    // URLs y rutas
    public static final String URL_HOLA = UrlConstant.URL_HOLA;
    public static final String URL_ADIVINA = UrlConstant.URL_ADIVINA;
    public static final String TEMPLATE_JUEGO = UrlConstant.TEMPLATE_JUEGO;
    public static final String TEMPLATE_ADIVINA = UrlConstant.TEMPLATE_ADIVINA;
    public static final String TEMPLATE_ESTADISTICAS = UrlConstant.TEMPLATE_ESTADISTICAS;

    // Configuración de Thymeleaf
    public static final String TEMPLATE_ENGINE_ATTR = ThymeleafConstants.TEMPLATE_ENGINE_ATTR;
    public static final String CONTENT_TYPE = ThymeleafConstants.CONTENT_TYPE;

    // Constantes del juego
    public static final int MAX_INTENTOS = GameConstants.MAX_INTENTOS;
    public static final int MIN_NUMERO = GameConstants.MIN_NUMERO;
    public static final int MAX_NUMERO = GameConstants.MAX_NUMERO;
    public static final String NUMERO_SECRETO = GameConstants.NUMERO_SECRETO;
    public static final String INTENTOS_RESTANTES = GameConstants.INTENTOS_RESTANTES;
    public static final String GAME_OVER = GameConstants.GAME_OVER;
    public static final String NOMBRE = GameConstants.NOMBRE;
    public static final String ESTADISTICAS = GameConstants.ESTADISTICAS;
    public static final String INTENTOS_USADOS = GameConstants.INTENTOS_USADOS;

    // Parámetros HTTP
    public static final String PARAM_NUMERO = GameConstants.PARAM_NUMERO;
    public static final String PARAM_REINICIAR = GameConstants.PARAM_REINICIAR;
    public static final String PARAM_NOMBRE = GameConstants.PARAM_NOMBRE;

    // Variables de contexto Thymeleaf
    public static final String VAR_INTENTOS = GameConstants.VAR_INTENTOS;
    public static final String VAR_NOMBRE = GameConstants.VAR_NOMBRE;
    public static final String VAR_NUMERO_SECRETO = GameConstants.VAR_NUMERO_SECRETO;
    public static final String VAR_INTENTOS_USADOS = GameConstants.VAR_INTENTOS_USADOS;
    public static final String VAR_ESTADISTICAS = GameConstants.VAR_ESTADISTICAS;
    public static final String VAR_PARTIDAS_GANADAS = GameConstants.VAR_PARTIDAS_GANADAS;
    public static final String VAR_PARTIDAS_PERDIDAS = GameConstants.VAR_PARTIDAS_PERDIDAS;
    public static final String VAR_GANASTE = GameConstants.VAR_GANASTE;
    public static final String VAR_GAME_OVER = GameConstants.VAR_GAME_OVER;
    public static final String VAR_MIN_NUMERO = GameConstants.VAR_MIN_NUMERO;
    public static final String VAR_MAX_NUMERO = GameConstants.VAR_MAX_NUMERO;

    // Mensajes
    public static final String MSG_NUMERO_MAYOR = MessageConstants.MSG_NUMERO_MAYOR;
    public static final String MSG_NUMERO_MENOR = MessageConstants.MSG_NUMERO_MENOR;
    public static final String MSG_NUMERO_INVALIDO = MessageConstants.MSG_NUMERO_INVALIDO;
    public static final String MSG_GANASTE = MessageConstants.MSG_GANASTE;
    public static final String MSG_GAME_OVER = MessageConstants.MSG_GAME_OVER;
    public static final String VAR_MENSAJE = MessageConstants.VAR_MENSAJE;
    public static final String VAR_ERROR = MessageConstants.VAR_ERROR;
}
