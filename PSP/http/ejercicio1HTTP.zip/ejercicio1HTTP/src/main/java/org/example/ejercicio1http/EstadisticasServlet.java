package org.example.ejercicio1http;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.example.config.Constants;
import org.example.domain.model.Estadisticas;
import org.example.domain.model.Partida;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.web.servlet.JakartaServletWebApplication;

import java.io.IOException;

@WebServlet("/estadisticas")
public class EstadisticasServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        HttpSession session = req.getSession();

        Estadisticas estadisticas = (Estadisticas) session.getAttribute(Constants.ESTADISTICAS);
        String nombre = (String) session.getAttribute(Constants.NOMBRE);

        int partidasGanadas = 0;
        int partidasPerdidas = 0;

        if (estadisticas != null && estadisticas.getPartidas() != null) {
            for (Partida partida : estadisticas.getPartidas()) {
                partidasGanadas += partida.getPartidasGandas();
                partidasPerdidas += partida.getPartidasPerdidas();
            }
        }

        var webExchange = JakartaServletWebApplication.buildApplication(getServletContext())
                .buildExchange(req, resp);
        WebContext ctx = new WebContext(webExchange);

        ctx.setVariable(Constants.VAR_NOMBRE, nombre);
        ctx.setVariable(Constants.VAR_ESTADISTICAS, estadisticas);
        ctx.setVariable(Constants.VAR_PARTIDAS_GANADAS, partidasGanadas);
        ctx.setVariable(Constants.VAR_PARTIDAS_PERDIDAS, partidasPerdidas);

        resp.setContentType(Constants.CONTENT_TYPE);
        ((TemplateEngine)getServletContext().getAttribute(Constants.TEMPLATE_ENGINE_ATTR))
                .process(Constants.TEMPLATE_ESTADISTICAS, ctx, resp.getWriter());
    }
}
