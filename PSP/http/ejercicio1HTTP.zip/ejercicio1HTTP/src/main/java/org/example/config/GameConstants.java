package org.example.config;

public class GameConstants {
    // Configuración del juego
    public static final int MAX_INTENTOS = 5;
    public static final int MIN_NUMERO = 1;
    public static final int MAX_NUMERO = 10;

    // Claves de sesión
    public static final String NUMERO_SECRETO = "numeroSecreto";
    public static final String INTENTOS_RESTANTES = "intentosRestantes";
    public static final String GAME_OVER = "gameOver";
    public static final String NOMBRE = "nombre";
    public static final String ESTADISTICAS = "estadisticas";
    public static final String INTENTOS_USADOS = "intentosUsados";

    // Parámetros HTTP
    public static final String PARAM_NUMERO = "numero";
    public static final String PARAM_REINICIAR = "reiniciar";
    public static final String PARAM_NOMBRE = "nombre";

    // Variables de contexto Thymeleaf
    public static final String VAR_INTENTOS = "intentos";
    public static final String VAR_NOMBRE = "nombre";
    public static final String VAR_NUMERO_SECRETO = "numeroSecreto";
    public static final String VAR_INTENTOS_USADOS = "intentosUsados";
    public static final String VAR_ESTADISTICAS = "estadisticas";
    public static final String VAR_PARTIDAS_GANADAS = "partidasGanadas";
    public static final String VAR_PARTIDAS_PERDIDAS = "partidasPerdidas";
    public static final String VAR_GANASTE = "ganaste";
    public static final String VAR_GAME_OVER = "gameOver";
    public static final String VAR_MIN_NUMERO = "minNumero";
    public static final String VAR_MAX_NUMERO = "maxNumero";
}
