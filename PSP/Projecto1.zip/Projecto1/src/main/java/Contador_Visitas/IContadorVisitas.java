package Contador_Visitas;

public interface IContadorVisitas {
    public void incrementarVisita();
    public int getContador();
}
